import os
from crewai.tasks.task_output import TaskOutput
from langchain_community.llms import Tongyi
from crewai import Agent, Task, Crew, Process
from authentications import DASHSCOPE_API_KEY
from crewai_tools import tool, SerperDevTool
import requests


# CrewAI核心概念：https://github.com/joaomdmoura/crewAI/tree/main/docs/core-concepts
# - Agent：一个具有特定职能和目标的个体，它被分配到特定的任务（Task）上，并执行该任务。
# - Task：Agent被分配到的任务，Agent执行该任务。
# - Crew：Agent和Task的容器，是Agent和Task的调度中心。


# +工具调用
@tool("Get HotSpots From Internet")
def get_hotspots(top_k_of_hotspots: int) -> list:
    """A tool that can get a list of the top k hotspots' title from Internet."""
    response = requests.get(url="http://api.1314.cool/getbaiduhot/")
    if response.status_code == 200:
        hotspots_groups = response.json()["data"]
        titles = [hotspots["word"] for hotspots in hotspots_groups[:top_k_of_hotspots]]
    else:
        titles = ["Failed to get any hotspots."]
    return titles


# +人机协同
@tool("Request cooperation with human")
def request_co_with_human(question: str) -> str:
    """A tool that can ask human questions to seek a string answer."""
    user_answer = input(f"针对问题【{question}】，您的答复是：")
    return user_answer


# +工具调用
toolset = [get_hotspots, request_co_with_human]

# DashScope API Key
os.environ["DASHSCOPE_API_KEY"] = DASHSCOPE_API_KEY
# langchain模型实例
llm = Tongyi(model_name="qwen-max")

# 创建Agent：编剧
screenwriter = Agent(
    # 角色、职能：决定了任务分配的优先级
    role="编剧",
    # 个体目标：对决策过程有参考意义
    goal="使用中文通过生动的描述、深刻的情感表达将提供的主题扩写为引人入胜的故事。",
    # 角色背景：丰富设定，加强输出风格
    backstory="早期先锋编剧，擅长各种风格的表现手法撰写剧本故事，在气氛营造、剧情表达以及人物塑造上表现出超一流的水准。",
    # 是否打印运行日志
    verbose=True,
    # 是否允许将任务委托给其他agent
    allow_delegation=False,
    # llm实例：langchain统一封装好的llm实例
    llm=llm,
    # +该agent的最大调用次数
    max_iter=15,
)

# 创建Agent：评论家
critic = Agent(
    role="评论家",
    goal="确保故事内容、行文风格、故事类型的一致性，并通过中文进行表达。",
    backstory="资深电影学教授，总是能捕捉到市场的需求和期待，" \
              "对故事中的叙事结构甚至是隐喻都有深入了解，善于发现故事中的情节漏洞和一些不易察觉的错误。",
    verbose=True,
    allow_delegation=False,
    llm=llm,
    # +该agent的最大调用次数
    max_iter=15,
)

# 创建Agent：策划
master = Agent(
    role="策划",
    goal="使用中文进行沟通，将数条网络热点串联起来提出剧作想法，跟进整个剧作的创作过程，管理编剧与评论家之间的协作，" \
         "确保最终所产出的故事能达到高水准，并且呈现出最终的、详细的完整剧本。",
    backstory="""经验老到的游戏叙事设计师，擅长使用高水平的情节框架与叙事细节调动读者的共情能力，使得读者获得沉浸式体验。""",
    verbose=True,
    allow_delegation=True,
    llm=llm,
    tools=toolset,
    # +该agent的最大调用次数
    max_iter=15,
)

# 创建Task
story_task = Task(
    # 对任务的描述、指令
    description=("基于网络热点话题使用中文撰写一个电影剧本。"
                 "并且应当问询human来进一步确认是否取用该答案或修改意见。"),
    # 用以完成任务的Agent
    agent=master,
    # 对任务完成情况的详细描述，即任务所追求的目标
    expected_output="一篇包含有数幕故事情节的电影剧本。",
    # 人类干预
    # user_input=True,
)

# 创建Crew
story_crew = Crew(
    # 可供协作完成任务的Agent列表
    agents=[screenwriter, critic, master],
    # 需要被执行的Task列表
    tasks=[story_task],
    # 是否打印运行日志
    verbose=False,
    # 工作流策略：sequential/hierarchical
    process=Process.sequential,
    language="Chinese",
)

# 执行Crew
story_output = story_crew.kickoff()
