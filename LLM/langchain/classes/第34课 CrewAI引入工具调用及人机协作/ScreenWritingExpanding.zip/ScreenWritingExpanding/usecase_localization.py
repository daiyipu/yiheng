from crewai import Agent
from crewai.utilities.i18n import I18N
import os
from authentications import DASHSCOPE_API_KEY
from langchain_community.llms import Tongyi

# DashScope API Key
os.environ["DASHSCOPE_API_KEY"] = DASHSCOPE_API_KEY
# langchain模型实例
llm = Tongyi(model_name="qwen-max")

# 创建Agent：编剧
screenwriter = Agent(
    # 角色、职能：决定了任务分配的优先级
    role="编剧",
    # 个体目标：对决策过程有参考意义
    goal="使用中文通过生动的描述、深刻的情感表达将提供的主题扩写为引人入胜的故事。",
    # 角色背景：丰富设定，加强输出风格
    backstory="早期先锋编剧，擅长各种风格的表现手法撰写剧本故事，在气氛营造、剧情表达以及人物塑造上表现出超一流的水准。",
    # 是否打印运行日志
    verbose=True,
    # 是否允许将任务委托给其他agent
    allow_delegation=False,
    # llm实例：langchain统一封装好的llm实例
    llm=llm,
    # +本土化prompt
    i18n=I18N(prompt_file="./zh.json")
)
