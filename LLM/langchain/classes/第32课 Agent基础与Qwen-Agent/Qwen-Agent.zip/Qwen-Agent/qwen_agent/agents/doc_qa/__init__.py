from .basic_doc_qa import BasicDocQA

__all__ = [
    'BasicDocQA',
]
