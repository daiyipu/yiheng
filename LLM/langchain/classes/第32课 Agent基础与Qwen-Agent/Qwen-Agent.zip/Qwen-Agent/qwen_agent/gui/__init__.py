from qwen_agent.gui.gradio import gr, mgr
from qwen_agent.gui.web_ui import WebUI

__all__ = [
    'gr',
    'mgr',
    'WebUI',
]
