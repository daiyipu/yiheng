import sys
from pathlib import Path

# This can be removed, if install qwen_agent by `pip install -e ./`
sys.path.insert(0, str(Path(__file__).absolute().parent.parent))
